package com.example.sprint5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private EditText ed_correo, ed_contraseña;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        auth = FirebaseAuth.getInstance(); //instanciar el firebase

        ed_correo = findViewById(R.id.edCorreoInicio);
        ed_contraseña = findViewById(R.id.edContraseñaInicio);

    }

    //Metodo para el boton de ingreso
    public void ingresar(View view){
        //leer los datos
        String correo = ed_correo.getText().toString();
        String contraseña = ed_contraseña.getText().toString();
        //iniciar sesion con estos datos y preguntar si estan correctas y si estan en la bd firebase
        auth.signInWithEmailAndPassword(correo, contraseña).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Ingreso fue Exitoso", Toast.LENGTH_LONG).show();
                    Intent in = new Intent(MainActivity.this, Administrador.class);
                    startActivity(in);
                }else{
                    Toast.makeText(MainActivity.this, "Ingreso NO Exitoso", Toast.LENGTH_LONG).show();
                }


            }
        });
    }

    //metodo para el boton de Registrar
    public void registrar (View view) {

        String correo = ed_correo.getText().toString();
        String contraseña = ed_contraseña.getText().toString();

        auth.createUserWithEmailAndPassword(correo, contraseña).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Registro fue Exitoso", Toast.LENGTH_LONG).show();
                }else {
                    Toast.makeText(MainActivity.this, "Registro NO exitoso", Toast.LENGTH_LONG).show();
                }
            }
        });

    }


}